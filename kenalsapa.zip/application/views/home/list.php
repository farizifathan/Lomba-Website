<?php
//load slider
include('slider.php');
//load slider
include('kategori.php');
//load data produk
include('produk.php');
?>
     
     